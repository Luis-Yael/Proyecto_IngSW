<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class bases_model extends CI_Model {

  function __construct()
    {parent::__construct();}

  public function validaLogin($data)
  {
    $cadena="select p.CURP,p.nombre,p.paterno,p.materno,p.foto,a.login,a.password  from administrador as a inner join persona as p on a.CURP=p.CURP where login='".$data['login']."' and password='".$data['password']."' ";
    $query = $this->db->query($cadena);
      if ($query->num_rows() > 0)
        return $query;
      else
        return FALSE;
  }

  public function validaLoginTutor($data)
  {
    $cadena="select p.CURP,p.nombre,p.paterno,p.materno,p.foto,a.login,a.password  from tutor as a inner join persona as p on a.CURP=p.CURP where login='".$data['login']."' and password='".$data['password']."' ";
    $query = $this->db->query($cadena);
      if ($query->num_rows() > 0)
        return $query;
      else
        return FALSE;
  }
    
  /*ingresa_nino*/
  
}
  
