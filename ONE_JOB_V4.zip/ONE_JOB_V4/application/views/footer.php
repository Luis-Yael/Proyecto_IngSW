<footer class="footer-sitio pt-3 mt-5">
    <div class="container">
            <div class="row">
                    <div class="col-md-4">
                        <h3 class="text-uppercase text-center pb-4">Nosotros</h3>
                        <p class="text-justify">Somos una empresa dedicada al reclutamiento de personas, nos caracterizamos por dar un trato justo a todos nuestros vcleintes..</p>
                    </div>
                    <div class="col-md-4 text-center">
                        <h3 class="text-uppercase pb-4">Horario</h3> 
                        <p>Lun-Vie: 9 AM - 7 PM</p>
                        <p>Sábado: 10 AM - 2 PM</p>
                        <p>Domingo: Cerrado</p>
                    </div>
                    <div class="col-md-4 text-center">
                        <h3 class="text-uppercase pb-4">Contacto</h3>
                        <p>19 oriente #1007 </p>
                        <p>El Angel, PA 1905</p>
                        
                        <nav class="sociales  pt-3">
                            <ul>
                                <li><a href="http://facebook.com" ><span class="sr-only" >Facebook</span></a></li>
                                <li><a href="http://twitter.com"><span class="sr-only">Twitter</span></a></li>
                                <li><a href="http://instagram.com"><span class="sr-only">Instagram</span></a></li>
                                <li><a href="http://pinterest.com"><span class="sr-only">Pinterest</span></a></li>
                                <li><a href="http://youtube.com"><span class="sr-only">YouTube</span></a></li>
                            </ul>
                        </nav>
                    </div>
                    
                    <div class="w-100"></div>
                    <hr class="w-100">
                    <p class="text-center copyright w-100">ONE JOB2017</p>
            </div>
    </div>
</footer>



<script src="http://localhost:8080/ONE_JOB_BUENO/js/jquery.js"></script>
<script src="http://localhost:8080/ONE_JOB_BUENO/js/tether.min.js"></script>
<script src="http://localhost:8080/ONE_JOB_BUENO/js/bootstrap.min.js"></script>
<script src="http://localhost:8080/ONE_JOB_BUENO/js/scripts.js"></script>
</body>
</html>