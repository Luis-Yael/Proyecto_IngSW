<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class bases_model extends CI_Model {

	function __construct(){
		parent::__construct();
	}

    public function _example_output($output = null)
    {
      
      $this->load->view('example.php',(array)$output);
      $this->load->view('footer');
    }


    	public function validaLogin($data){
		    $cadena="select id_candidato,nombre_cand,ap_paterno,ap_materno from candidato where login_cand='".$data['login']."' and pwd_cand='".$data['password']."'";
		
		    $query = $this->db->query($cadena);
		//echo var_dump($query);
		      if ($query->num_rows() > 0)
		        return $query;
		      else
		        return FALSE;
  }
}